# AI Simulation Platform

A unified web-based learning platform for AI concepts. This repository contains the frontend and backend for an interactive simulation that covers 11 modules of AI, from data basics to governance and leadership. The project is set up for deployment to Render (or similar platforms).

## Project structure

- `frontend`: React application. Use `npm install` and `npm start`.
  - `public`: static HTML file.
  - `src`: JS files.
- `backend`: FastAPI application. Use `pip install -r requirements.txt` and `uvicorn main:app --reload`.
